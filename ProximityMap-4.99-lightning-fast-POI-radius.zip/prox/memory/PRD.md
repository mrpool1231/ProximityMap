# MapApp (formerly GeoPulse Studio) — PRD

## Original problem statement
> i need an app about maps that can be over layed by any additional parameter

## Product summary
GeoPulse Studio is a dark, cartographer-grade single-page map workstation.
Users pan/zoom a Leaflet basemap, toggle any combination of overlay layers,
drop a pin / search an address / draw or upload a property outline, and see
everything within an adjustable buffer grouped by category with per-item
distance measured from the property line. Pro features (PDF brief, share
links) are unlocked with a one-time Stripe payment.

## User personas
- **Property scout / owner** — profiles a parcel by nearby amenities.
- **Data explorer** — layers custom GeoJSON/CSV data on a live basemap.
- **Casual curious user** — clicks the map to explore weather / AQI / elevation.

## Core requirements (static)
- Leaflet + OpenStreetMap (dark-filtered), free — no keys.
- Built-in POI layers (parks, schools, daycares, gas stations, hospitals,
  restaurants, supermarkets, EV chargers).
- Environmental overlays: live weather, US AQI, elevation (Open-Meteo).
- Address search (Nominatim) + drop-a-pin + property outline (draw/upload).
- Adjustable buffer radius (100 m – 10 km) measured from property lines.
- Per-layer visibility toggle + opacity slider.
- Custom GeoJSON / CSV upload → live overlay stored in MongoDB.
- Single-user, no auth. Pro unlock via Stripe, license kept in localStorage.

## What's been implemented
### 2026-02-15 — MVP
- FastAPI backend: `/api/pois` (Overpass + curated NYC + synthetic fallback),
  `/api/geocode`, `/api/weather`, `/api/air-quality`, `/api/elevation`,
  custom layers CRUD.
- React three-pane workstation (Layer Control / Map / Proximity Analysis),
  upload modal, basemap swap, legend.

### 2026-09-17 — Property polygon, sharing, traffic, print, Stripe
- **Property outline**: draw on map (PropertyTools) or upload GeoJSON polygon;
  buffer = turf buffer of polygon; POI distances = distance to boundary (0 if
  inside). Pin snaps to centroid. `/app/frontend/src/lib/geo.js`.
- **Share links**: `POST/GET /api/reports/{id}` (Mongo `reports`), URL
  `/?report=<id>` restores pin/property/radius/layers/opacity/basemap.
- **Live traffic**: TomTom flow tiles proxied at
  `/api/traffic/tiles/{z}/{x}/{y}.png`; `/api/traffic/config` reports
  `enabled` (needs `TOMTOM_API_KEY` in backend/.env — currently EMPTY, layer
  shows a warning).
- **Print brief**: `PrintReport.jsx` portal overlay (light theme, static map,
  env stats, amenity tables) + `@media print` CSS → browser Save-as-PDF.
- **Stripe (Flow A claimable sandbox, tax mode "full")**: `payments.py` —
  `GET /api/payments/products`, `POST /api/payments/checkout`,
  `GET /api/payments/status/{id}` (polls Stripe as webhook fallback),
  `POST /api/stripe/webhook`. Catalog in `setup_stripe.py`
  (product `geopulse_pro`, price lookup_key `geopulse_pro_onetime`, $9 one-time,
  tax code txcd_10000000). Frontend: `UpgradeDialog`, `/payment/success`,
  `/payment/cancel`, `lib/license.js` (localStorage license + resume state).
  Share + Print are Pro-gated; TopBar shows "Go Pro" or "Pro" badge.
- Testing: iteration_3 (100% pass), iteration_4 (backend 100%; frontend all
  pass except automated Stripe UI completion which the agent couldn't drive;
  bogus-license bug fixed and self-verified).

### 2026-09-19 — Accounts, branding, compare
- **Auth (JWT, httpOnly cookies)**: `auth.py` — register/login/logout/refresh/
  me, bcrypt, 5-fail lockout, admin seeded from env (`ADMIN_EMAIL`,
  `ADMIN_PASSWORD`, `JWT_SECRET` in backend/.env). Frontend `AuthContext`,
  `AuthDialog`, `AccountMenu` in TopBar; axios `withCredentials` + silent
  refresh interceptor. Pro = account `is_pro` OR device license; device
  license auto-claimed to the account on login (`POST /api/auth/claim-license`);
  Stripe checkout attaches `user_id`, payment confirmation sets `users.is_pro`.
- **Brief branding**: `PUT /api/auth/branding`, logo upload to Emergent Object
  Storage (`storage.py`, `POST/GET/DELETE /api/auth/branding/logo`),
  `BrandingDialog`; PrintReport renders a branded header.
- **Compare properties**: outline B (teal) via `PropertyTools`, own POI fetch,
  `CompareScorecard` (count + nearest per category, row winners, verdict) in
  the panel and in the print brief; B included in share-link state.
- Traffic layer LIVE since 2026-09-20 (user supplied TOMTOM_API_KEY; stored in backend/.env).
- Testing: iteration_5 — backend 16/16, all frontend flows pass.

### 2026-09-19 — ChatGPT integration
- `ai.py` (OpenAI **gpt-5.4** via emergentintegrations + `EMERGENT_LLM_KEY`):
  `POST /api/ai/chat` (SSE streaming, multi-turn; history in Mongo
  `ai_messages` keyed by `session_id`, replayed into the system prompt),
  `GET/DELETE /api/ai/history/{session}`, `POST /api/ai/summary` (one-shot
  streamed brief narrative), `GET /api/ai/config`.
- Frontend: `AIAnalyst` floating chat over the map (context = pin/radius/
  counts/nearest/env/A-vs-B via `lib/ai.js buildAIContext`), 3 free questions
  for anonymous users then paywall, unlimited for Pro. `AISummary` section in
  the print brief ("Generate with ChatGPT").
- Testing: iteration_6 — backend 8/8, all frontend flows pass.

### 2026-09-20 — Location-accuracy audit + rename to MapApp
- **Removed all fabricated POI data** (curated NYC list + synthetic generator,
  both backend and frontend). POIs are live OpenStreetMap only; browser
  Overpass and backend `/api/pois` are raced per category; failures surface
  as `unavailable` with a banner + Retry (never substituted). Queries use
  `nwr` (relations included), park filter = park + nature_reserve, results
  with centroid beyond the radius are dropped, `source: "osm"` returned.
- Renamed app to **MapApp** everywhere (title, header, brief, dialogs, AI
  persona, Stripe product name, API title). localStorage keys unchanged.
- Testing: iteration_7 — pass (one edge case fixed afterwards: way centroid
  just beyond radius now filtered).

### 2026-09-20 — Launch prep (items 1–6)
- TomTom basemaps (night/main/sat+hybrid) proxied via `/api/basemap/{style}/{z}/{x}/{y}`;
  OSM/Esri tile servers no longer used. Geocoding → TomTom Search with Nominatim fallback.
- Admin credentials rotated (admin@mapapp.app, see test_credentials.md); old admin deleted.
- Legal pages `/legal/terms|privacy|refunds` (LegalPage.jsx) linked from TopBar, Upgrade & Auth dialogs.
- Deployment agent check: pass. Stripe account claim (KYC) is a user action.
- Testing: iteration_8 — backend 11/11, frontend all pass.

### 2026-09-20 — Password reset by email
- Emergent managed email (`emailer.py`, EMERGENT_EMAIL_KEY + EMAIL_FROM_NAME="MapApp").
  `POST /api/auth/forgot-password` (generic response, 3/hour, sha256 token, 1h TTL) and
  `POST /api/auth/reset-password` (single-use, signs user in). UI: "Forgot your password?"
  in AuthDialog, `/reset-password?token=` page. Testing: iteration_9 — 9/9 backend, 8/8 frontend.
- Deployment: user publishes via Publish panel; custom domain via Publish → Manage Publishes → Domain.

## Design system
See `/app/design_guidelines.json` — Outfit / Manrope / IBM Plex Mono type,
`#0B0F17` obsidian base + tactical signal accent (`#38BDF8`, `#F59E0B`,
`#10B981`, `#EF4444`), glass-morphism panels.

## Prioritized backlog
### P1

- Population density heatmap (real data source).
### P2
- Time-slider for weather / AQI trends.
- Measure-distance and area tools.
- Commercial tile provider before going live (OSM tile policy).

## Known constraints
- Overpass / Nominatim can be flaky from headless environments; app falls back
  to curated + synthetic data.
- React StrictMode disabled intentionally (react-leaflet 4.2.1).
- Stripe webhooks may not reach preview; status endpoint polls Stripe directly.
- Anonymous Pro purchases stay device-local until the buyer signs in (then
  they are claimed to the account).
