# MapApp improvements

This archive contains the modified source files for the MapApp layer/workspace improvements.

Key changes:
- Corrected OSM layer filters on both browser and backend paths and deduplicated multi-tag matches.
- Removed the non-functional Population Density layer from the layer control.
- Environmental controls now correctly control the environmental data shown in the analysis panel rather than pretending to be map overlays.
- Traffic is disabled in the UI when no TomTom key is configured.
- Added 500 ft / 1,000 ft / 2,000 ft / 1/4 mi / 1/2 mi / 1 mi radius presets.
- Added browser geolocation / My Location control.
- Added mobile layer and analysis drawers.
- Hardened custom GeoJSON popup rendering against HTML injection.

The frontend build was not executed in this environment because the uploaded source archive intentionally excluded node_modules and dependency installation could not complete within the available execution time. Python backend syntax was compiled successfully.
