Developer Pro testing

Set DEV_PRO_EMAILS in the backend environment to the email address(es) you use for testing, comma-separated.
Example:
DEV_PRO_EMAILS=your-email@example.com

After restarting the backend, signing in with that account will report is_pro=true without requiring a Stripe payment. Production customers still require the normal paid subscription.
